import time
import os
from pytube import YouTube

def telecharger_video_4k_youtube(url, emplacement):
    try:
        
        video = YouTube(url)
        stream = video.streams.filter(res="2160p").first()  
        chemin_complet = os.path.join(emplacement, f"{video.title}.mp4")
        print(f"Téléchargement en cours : {video.title} (4K)...")
        stream.download(output_path=emplacement, filename=f"{video.title}.mp4")
        print("\nTéléchargement terminé avec succès!")
        print(f"La vidéo a été sauvegardée dans : {chemin_complet}")
        return True
    except Exception as e:
        print(f"Une erreur s'est produite lors du téléchargement de la vidéo : {str(e)}")
        return False

def menu():
    print("=====    telecharge des video youtube gratuit Discord :sbdjoumi.   =====")
    print("1. Télécharger une vidéo YouTube en qualité 4K")
    print("2. Quitter")
    choix = input("Entrez votre choix (1 ou 2) : ")
    return choix

def regarder_et_telecharger_film_4k_youtube():
    try:
        while True:
            choix = menu()
            if choix == "1":
                url_du_film = input("Entrez l'URL de la vidéo YouTube : ")
                emplacement_de_sauvegarde = os.path.dirname(os.path.abspath(__file__))
                if telecharger_video_4k_youtube(url_du_film, emplacement_de_sauvegarde):
                    time.sleep(2)  # Attendre 2 secondes
                    continue  # Retourner directement au menu
            elif choix == "2":
                print("Merci d'avoir utilisé le programme. Au revoir!")
                break
            else:
                print("Choix invalide. Veuillez entrer 1 ou 2.")

    except Exception as e:
        print(f"Une erreur s'est produite : {str(e)}")

regarder_et_telecharger_film_4k_youtube()
